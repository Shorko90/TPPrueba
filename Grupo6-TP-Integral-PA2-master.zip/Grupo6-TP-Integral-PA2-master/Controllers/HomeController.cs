﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebMVC3.Models;
using WebMVC3.Models.ViewModels;

namespace WebMVC3.Controllers
{
    public class HomeController : Controller
    {
        private readonly WEBMVC2Context _DBContext;

        public HomeController(WEBMVC2Context context)
        {
            _DBContext = context;
        }

        //Generar indice para listado
        public IActionResult Index()
        {
            List < Libro > Libros = _DBContext.Libros.Include(c => c.oGenero).ToList();
            return View(Libros);
        }

        //Mostrar formulario para creacion o modificacion de entrada
        [HttpGet]
        public IActionResult Libro_Detalle(int IdLibros)
        {
            LibroVM oLibroVM = new LibroVM()
            {
                oLibro = new Libro(),
                oListaGenero = _DBContext.Generos.Select(Genero => new SelectListItem()
                {
                    Text = Genero.Genero1,
                    Value = Genero.IdGenero.ToString()

                }).ToList()
            };

            if (IdLibros != 0)
            {
                oLibroVM.oLibro = _DBContext.Libros.Find(IdLibros);
            }

            return View(oLibroVM);
        }

        [HttpPost]
        public IActionResult Libro_Detalle(LibroVM oLibroVM)
        {
            if (oLibroVM.oLibro.IdLibros == 0)
            {
                _DBContext.Libros.Add(oLibroVM.oLibro);
            }
            else
            {
                _DBContext.Libros.Update(oLibroVM.oLibro);
            }

            if (!ModelState.IsValid)
            {
                return View(oLibroVM);
            }


            _DBContext.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        //Mostrar formulario para eliminacion de entrada
        [HttpGet]
        public IActionResult Libro_Eliminar(int IdLibros)
        {
            Libro oLibro = _DBContext.Libros.Include(c => c.oGenero).Where(e => e.IdLibros == IdLibros).FirstOrDefault();
            return View(oLibro);
        }

        [HttpPost]
        public IActionResult Libro_Eliminar(Libro oLibro)
        {
            _DBContext.Libros.Remove(oLibro);
            _DBContext.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
    }
}