﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebMVC3.Models;
using WebMVC3.Services;

namespace WebMVC3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibroController : ControllerBase
    {
        #region Property  
        private readonly ILibroService _libroService;
        #endregion

        #region Constructor  
        public LibroController(ILibroService libroService)
        {
            _libroService = libroService;
        }
        #endregion

        [HttpGet(nameof(GetLibro))]
        public async Task<string> GetLibro(int Id)
        {
            var result = await _libroService.GetLibro(Id);
            return result;
        }
        [HttpGet(nameof(GetLibroDetails))]
        public async Task<Libro> GetLibroDetails(int Id)
        {
            var result = await _libroService.GetLibroDetails(Id);
            return result;
        }
    }
}