<!--
*** Thanks for checking out this README Template. If you have a suggestion that would
*** make this better, please fork the repo and create a pull request or simply open
*** an issue with the tag "enhancement".
*** Thanks again! Now go create something AMAZING! :D
***
***
***
*** Para evitar volver a escribir demasiada información. Haga una búsqueda y reemplace por lo siguiente:
*** github_username, repo, twitter_handle, email
-->






<!-- PROJECT SHIELDS -->
<!--
*** I'm using markdown "reference style" links for readability.
*** Reference links are enclosed in brackets [ ] instead of parentheses ( ).
*** See the bottom of this document for the declaration of the reference variables
*** for contributors-url, forks-url, etc. This is an optional, concise syntax you may use.
*** https://www.markdownguide.org/basic-syntax/#reference-style-links
-->
[![contributors][contributors-shield]][contributors-url]



<!-- PROJECT LOGO -->
<br />
<p align="center">
  <a href="https://github.com/github_username/repo">
    <img src="https://expoproyecto.unlam.edu.ar/e/images/unlam-dos-lineas.png" alt="Logo" width="30%" height="30%">
  </a>

  <h3 align="center">TRABAJO PRACTICO INTEGRAL</h3>

  <p align="center">
    GRUPO 6 - UNLAM - CABA - 2022
    <br />
    <br />
    <br />
  </p>
</p>
<!-- TABLE OF CONTENTS -->

## Tabla de contenidos

* [Acerca del proyecto](#Acerca-del-proyecto)
* [Configuracion Inicial](#Configuracion-Inicial)
  * [Prerequisitos](#prerequisitos)
  * [Instalacion](#instalacion)
* [Usage](#usage)
* [Roadmap](#roadmap)
* [Contributing](#contributing)
* [License](#license)
* [Contact](#contact)
* [Acknowledgements](#acknowledgements)



<!-- ABOUT THE PROJECT -->
## Acerca del proyecto


Trabajo práctico donde se elabora un proyecto para listar libros

### Integrantes:


:raising_hand_man: Altamirano, Hernán Maximiliano

:raising_hand_man: Crespo Choque Ruddy

:raising_hand_man: Modula Emiliano

:raising_hand_man: Picon, Fernando Cristian

:raising_hand_man: Sanchez Vilchez Luis

:raising_hand_man: Saracho Lucas Agustin

:raising_hand_man: Sierra, Jonathan



<!-- GETTING STARTED -->
## Configuracion Inicial

.Clonar el repositorio
.Tener instalado .NET Framework 
.Tener instalado SQL Express

### Prerequisitos

.Tener instalado .NET Framework 
.Tener instalado SQL Express

### Instalacion

1. Clonar el repositorio
```sh
git clone https://github.com/HMA86/Grupo6-TP-Integral-PA2
```

2. Crear BBDD vacía con nombre "WEBMVC2" e importar contenido del archivo "PA2_Base.xlsx" localizado en la carpeta "Base" de este proyecto.
 
<!-- CONTRIBUTING -->
## Contributing

Las contribuciones son lo que hace que la comunidad de código abierto sea un lugar increíble para aprender, inspirar y crear. Cualquier contribución que hagas es muy apreciada.

1. bifurcar el proyecto
2. Cree su rama de características (`git checkout -b feature/AmazingFeature`)
3. Confirme sus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Empujar a la sucursal (`git push origin feature/AmazingFeature`)
5. Abrir una solicitud de extracción.



<!-- LICENSE -->
## Licencia

Distribuido bajo la licencia MIT. Consulte `LICENCIA` para obtener más información.



<!-- CONTACT -->
## Contact
Altamirano, Hernán Maximiliano, haltamirano@alumno.unlam.edu.ar

Crespo Choque Ruddy, rcrespochoque@alumno.unlam.edu.ar

Modula Emiliano, emodula@alumno.unlam.edu.ar

Picon, Fernando Cristian, fepicon@alumno.unlam.edu.ar

Sanchez Vilchez Luis, lsanchezvilchez@alumno.unlam.edu.ar

Saracho Lucas Agustin, lsaracho@alumno.unlam.edu.ar

Sierra, Jonathan, josierra@alumno.unlam.edu.ar







Project Link: [https://github.com/github_username/repo](https://github.com/github_username/repo)



<!-- ACKNOWLEDGEMENTS -->
## Acknowledgements

* []()
* []()
* []()

Archivo de pruebas por API : TPintegralPostman.postman_collection.json



<!-- MARKDOWN LINKS & IMAGES -->
<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->
[contributors-shield]: https://img.shields.io/badge/contributors-grey?style=flat&logo=github
[contributors-url]: https://github.com/menendezg/VM-System/graphs/contributors
[product-screenshot]: screenshot.png
