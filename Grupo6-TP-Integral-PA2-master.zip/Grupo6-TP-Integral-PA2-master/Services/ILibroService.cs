﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebMVC3.Models;

namespace WebMVC3.Services
{
    public interface ILibroService
    {
        Task<string> GetLibro(int Id);
        Task<Libro> GetLibroDetails(int Id);
    }
}