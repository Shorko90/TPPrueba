﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebMVC3.Models;
using Microsoft.EntityFrameworkCore;

namespace WebMVC3.Services
{
    public class LibroService : ILibroService
    {
        #region Property  
        private readonly WEBMVC2Context _appDbContext;
        #endregion

        #region Constructor  
        public LibroService(WEBMVC2Context appDbContext)
        {
            _appDbContext = appDbContext;
        }
        #endregion

        public async Task<string> GetLibro(int Id)
        {
            var name = await _appDbContext.Libros.Where(e => e.IdLibros == Id).Select(e => e.Nombre).FirstOrDefaultAsync();
            return name;
        }

        public async Task<Libro> GetLibroDetails(int Id)
        {
            var book = await _appDbContext.Libros.FirstOrDefaultAsync(e => e.IdLibros == Id);
            return book;
        }
    }
}