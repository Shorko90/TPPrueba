﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WebMVC3.Controllers;
using WebMVC3.Models;
using Moq;
using Microsoft.EntityFrameworkCore;

namespace WebMVC3_UT
{    public class HomeControllerTest
    {
        [Fact]
        public List<Genero> GetTestGenero()
        {
            var genero = new List<Genero>();
            genero.Add(new Genero()
            {
                IdGenero = 100,
                Genero1 = "Deportes"
            });
            genero.Add(new Genero()
            {
                IdGenero = 101,
                Genero1 = "Literatura Checoslovaca"
            });
            return genero;
        }
    }
}
