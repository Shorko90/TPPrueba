using Moq;
using WebMVC3.Controllers;
using WebMVC3.Models;
using WebMVC3.Services;

namespace UnitTesting
{
    public class LibroTest
    {
        #region Property
        public Mock<ILibroService> mock = new Mock<ILibroService>();
        #endregion

        [Fact]
        public async void GetLibro()
        {
            mock.Setup(p => p.GetLibro(1)).ReturnsAsync("Lobos sin Danzas");
            LibroController book = new LibroController(mock.Object);
            string result = await book.GetLibro(1);
            Assert.Equal("Lobos sin Danzas", result);
        }

        [Fact]
        public async void GetLibroDetails()
        {
            var libro = new Libro()
            {
                IdLibros = 99,
                Nombre = "La Aventura del Hombre",
                Autor = "Messi",
                Editorial = "La Tercera",
                Precio = 1500,
                Comentarios = "La vencida"
            };
            mock.Setup(p => p.GetLibroDetails(1)).ReturnsAsync(libro);
            LibroController book = new LibroController(mock.Object);
            var result = await book.GetLibroDetails(1);
            Assert.True(libro.Equals(result));
        }
    }
}