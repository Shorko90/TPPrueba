﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

//Modelo para generar listado de genero

namespace WebMVC3.Models.ViewModels
{
    public class LibroVM
    {
        public Libro oLibro { get; set; }
        public List<SelectListItem>? oListaGenero { get; set; }

    }
}