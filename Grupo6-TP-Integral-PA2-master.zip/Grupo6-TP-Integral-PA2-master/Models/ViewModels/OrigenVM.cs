﻿using Microsoft.AspNetCore.Mvc.Rendering;

//Modelo para generar listado de genero

namespace WebMVC3.Models.ViewModels
{
    public class OrigenVM
    {
        public Libro oOrigen { get; set; }
        public List<SelectListItem>? oListaOrigen { get; set; }

    }
}
