﻿using System;
using System.Collections.Generic;

namespace WebMVC3.Models
{
    public partial class Origen
    {
        public Origen()
        {
            Libros = new HashSet<Libro>();
        }

        public int IdOrigen { get; set; }
        public string? Pais { get; set; }

        public virtual ICollection<Libro> Libros { get; set; }
    }
}
