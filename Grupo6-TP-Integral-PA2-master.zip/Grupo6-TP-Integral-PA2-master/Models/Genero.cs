﻿using System;
using System.Collections.Generic;

namespace WebMVC3.Models
{
    public partial class Genero
    {
        public Genero()
        {
            Libros = new HashSet<Libro>();
        }

        public int IdGenero { get; set; }
        public string? Genero1 { get; set; }
        public virtual ICollection<Libro> Libros { get; set; }
    }
}
