﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

//Modelado de BBDD

namespace WebMVC3.Models
{
    public partial class WEBMVC2Context : DbContext
    {
        public WEBMVC2Context()
        {
        }

        public WEBMVC2Context(DbContextOptions<WEBMVC2Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Genero> Generos { get; set; } = null!;
        public virtual DbSet<Libro> Libros { get; set; } = null!;
       

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Genero>(entity =>
            {
                entity.HasKey(e => e.IdGenero)
                    .HasName("PK__GENERO__0F8349888DB0E600");

                entity.ToTable("GENERO");

                entity.Property(e => e.Genero1)
                    .HasMaxLength(32)
                    .IsUnicode(false)
                    .HasColumnName("Genero");
            });

            modelBuilder.Entity<Libro>(entity =>
            {
                entity.HasKey(e => e.IdLibros)
                    .HasName("PK__LIBROS__153221F3E26268BB");

                entity.ToTable("LIBROS");

                entity.Property(e => e.Autor)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Comentarios)
                    .HasMaxLength(96)
                    .IsUnicode(false);

                entity.Property(e => e.Editorial)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Nombre)
                    .HasMaxLength(64)
                    .IsUnicode(false);

                entity.Property(e => e.Precio).HasColumnType("decimal(10, 0)");

                entity.HasOne(d => d.oGenero)
                    .WithMany(p => p.Libros)
                    .HasForeignKey(d => d.IdGenero)
                    .HasConstraintName("FK_Genero");

               
            });

      

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}