﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebMVC3.Models
{
    public partial class Libro
    {
        public int IdLibros { get; set; }
        [Required]
        public string? Nombre { get; set; }
        public string? Autor { get; set; }
        public string? Editorial { get; set; }
        public decimal? Precio { get; set; }
        public string? Comentarios { get; set; }
        public int? IdGenero { get; set; }
      
        public virtual Genero? oGenero { get; set; }
       
    }
}
